# Contributing to Sentora

Thanks for taking the time to contribute!

The following is a set of guidelines for contributing to Sentora (https://github.com/sentora) on GitHub.
These are just guidelines, not rules.

Please check before contributing our dev section in the forums.

For all bug fixes please use the bug fix branche. For new features/enhancement please check our roadmap first so it won't collide with another member of the team.

### Our dev forum:

http://forums.sentora.org/forumdisplay.php?fid=54

### Roadmap:

http://forums.sentora.org/showthread.php?tid=2608

http://forums.sentora.org/showthread.php?tid=2613

V 0.0.1 alpha
